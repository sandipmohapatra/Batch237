package in.nareshit.raghu.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Product {

	@Id
	@GeneratedValue
	private Integer prodId;
	
	private String prodCode;
	private Integer prodCost;
	private String prodType;
	private String prodNote;
	
	private Integer prodDiscount;
	private Integer prodGst;
	
	public Integer getProdId() {
		return prodId;
	}
	public void setProdId(Integer prodId) {
		this.prodId = prodId;
	}
	public String getProdCode() {
		return prodCode;
	}
	public void setProdCode(String prodCode) {
		this.prodCode = prodCode;
	}
	public Integer getProdCost() {
		return prodCost;
	}
	public void setProdCost(Integer prodCost) {
		this.prodCost = prodCost;
	}
	public String getProdType() {
		return prodType;
	}
	public void setProdType(String prodType) {
		this.prodType = prodType;
	}
	public String getProdNote() {
		return prodNote;
	}
	public void setProdNote(String prodNote) {
		this.prodNote = prodNote;
	}
	public Integer getProdDiscount() {
		return prodDiscount;
	}
	public void setProdDiscount(Integer prodDiscount) {
		this.prodDiscount = prodDiscount;
	}
	public Integer getProdGst() {
		return prodGst;
	}
	public void setProdGst(Integer prodGst) {
		this.prodGst = prodGst;
	}
	
}
