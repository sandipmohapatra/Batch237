package com.sandip.SpringDataJPA1;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.Ordered;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

@Component
public class MySqlJPADemo implements CommandLineRunner,Ordered
{
@Autowired
private JdbcTemplate jt;
	@Override
	public void run(String... args) throws Exception 
	{
		System.out.println("First execution");
		String x="insert into student values(?,?,?)";
		int c=jt.update(x,105,"peter","Bangalore");
		System.out.println(c+" One row inserted");
	}
	@Override
	public int getOrder() {
		
		return 10;
	}

}
