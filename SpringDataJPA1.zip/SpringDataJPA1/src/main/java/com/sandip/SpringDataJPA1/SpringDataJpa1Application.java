package com.sandip.SpringDataJPA1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringDataJpa1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringDataJpa1Application.class, args);
	}

}
