package com.example.demo;
import java.util.Scanner;
import org.springframework.stereotype.Component;
@Component("emp")
public class Employee
{
int empno;
String name,address;
public void input()
{
	Scanner ob=new Scanner(System.in);
	System.out.println("enter empno,name,address");
	empno=ob.nextInt();
	name=ob.next();
	address=ob.next();
}
public void display()
{
	System.out.println("the empono is "+empno);
	System.out.println("the empname is "+name);
	System.out.println("the emp address is "+address);
	
}
}
