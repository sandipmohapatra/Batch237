import java.io.*;  
import javax.servlet.*;  
import javax.servlet.http.*;  
import java.sql.*;  
import javax.servlet.annotation.WebServlet;  
@WebServlet("/FetchData")
public class FetchData extends HttpServlet {  
      
public void doGet(HttpServletRequest request, HttpServletResponse response)  
        throws ServletException, IOException {  
  
response.setContentType("text/html");  
PrintWriter out = response.getWriter();  
      
try{  
//Retrieving connection object from ServletContext object  
ServletContext ctx=getServletContext();  
Connection con=(Connection)ctx.getAttribute("mycon");  
     
PreparedStatement ps=con.prepareStatement("select * from employee");
              
ResultSet rs=ps.executeQuery();  
while(rs.next())
{  
out.print("<br> "+rs.getInt(1)+" "+rs.getString(2)+" "+rs.getInt(3));  
}  
              
con.close();  
}catch(Exception e){e.printStackTrace();}  
          
out.close();  
}  
}  