package springcore1;

public class Employee
{
private int empid;
private String name,address;
private Bank bank;
public Employee(int empid, String name, String address,Bank bank) 
{
	this.empid = empid;
	this.name = name;
	this.address = address;
	this.bank=bank;
}
@Override
public String toString() {
	return "Employee [empid=" + empid + ", name=" + name + ", address=" + address + ", bank=" + bank + "]";
}



 



}
