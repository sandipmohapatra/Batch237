package com.sandip;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
public class Test 
{
public static void main(String[] args) 
{
ApplicationContext ctx=new ClassPathXmlApplicationContext("applicationContext.xml");
EmployeeDao dao=(EmployeeDao)ctx.getBean("edao");

boolean status=dao.saveEmployee(new Employee(104,"deepak",65000.00f));
System.out.println(status);

}
}
