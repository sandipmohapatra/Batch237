	package com.app.aspect; 
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component; 
		 
		@Component 
		@Aspect 
		public class LoggingAspect { 
		  
		 @Pointcut("execution(public  *  sh*(..))")  
		 	 public void point1() { 
		   System.out.println("Method");
		 } 
		  
		 @Before("point1()") 
		 public void showLog() { 
		  System.out.println("I m from Before Advice()"); 
		 } 
		 
		 @After("point1()") 
		 public void showLog1() { 
		  System.out.println("I m from After Advice()"); 
		 } 
		
		 @AfterReturning("point1()")
		    public void showLog2() {
		        System.out.println("Method executed successfully, returned ");
		    }

		    @AfterThrowing("point1()")
		    public void showLog3() {
		        System.out.println("Method threw an error: ");
		    }
		    
		    @Around("point1()") 
		    public void getMsg(ProceedingJoinPoint   jp)
		    { 
		    System.out.println("From 1st part of Around"); 
		    try{ 
		     Object ob = jp.proceed(); 
		    }
		    catch(Throwable t) 
		    { 
		     System.out.println(t); 
		    } 
		    System.out.println("From 2nd  part of Around"); 
		    } 
		    } 
		 
	


