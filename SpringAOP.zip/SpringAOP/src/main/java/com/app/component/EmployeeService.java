package com.app.component; 
import org.springframework.stereotype.Service; 

@Service 
public class EmployeeService { 

	public String showMsg() 
	{ 
		System.out.println("Hello I m from Business Method()");
		return "Hello Message";
	} 
}


