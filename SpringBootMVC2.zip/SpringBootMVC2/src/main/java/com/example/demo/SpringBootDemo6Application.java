package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootDemo6Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootDemo6Application.class, args);
	}

}
