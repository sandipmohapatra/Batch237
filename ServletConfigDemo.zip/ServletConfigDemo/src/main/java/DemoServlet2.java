import java.io.*;  
import javax.servlet.*;  
import javax.servlet.http.*;  
  
public class DemoServlet2 extends HttpServlet 
{  
public void doGet(HttpServletRequest request, HttpServletResponse response)  
    throws ServletException, IOException {  
  
    response.setContentType("text/html");  
    PrintWriter out = response.getWriter();  
      
    ServletConfig config=getServletConfig();  
    String driver=config.getInitParameter("driver");  
    out.print("Driver is: "+driver);  
    out.print("<br>");
    String username=config.getInitParameter("username");  
    out.print("Username is: "+username);
    out.print("<br>");
    String password=config.getInitParameter("password");  
    out.print("Password is: "+password);
    out.print("<br>");
    //**************************************************************************** 
    ServletContext context=getServletContext();  
   //Getting the value of the initialization parameter and printing it  
  String x=context.getInitParameter("x");  
  out.println("value of x is ="+x);  
  out.print("<br>");
  String y=context.getInitParameter("y");  
  out.println("value of y is ="+y);  
  out.print("<br>");
  int sum=Integer.parseInt(x)+Integer.parseInt(y);
  
  out.println("The sum is "+sum);
  
  String n=(String)context.getAttribute("company");  
  out.println("<br>");
  out.println("The Company name is "+n);
    out.close();  
    }  
  
}  