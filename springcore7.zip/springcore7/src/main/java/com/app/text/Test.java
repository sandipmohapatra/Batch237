package com.app.text; 

import org.springframework.context.ApplicationContext; 
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.app.Employee; 
 public class Test 
 { 
 public static void main(String[] args) 
 { 
ApplicationContext ac = new ClassPathXmlApplicationContext("config.xml"); 
  Employee e1 = (Employee)ac.getBean("empObj"); 
  System.out.println(e1.hashCode()); 
  System.out.println(e1.getAddr().hashCode()); 
   
  Employee e2 = (Employee)ac.getBean("empObj");
  System.out.println(e2.hashCode()); 
  System.out.println(e2.getAddr().hashCode()); 
   
  Employee e3 = (Employee)ac.getBean("empObj"); 
  System.out.println(e3.hashCode()); 
  System.out.println(e3.getAddr().hashCode()); 
  
    } 
}

